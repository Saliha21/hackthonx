<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Ads</title>
	  <!-- Custom fonts for this theme -->
	 <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	 <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	 <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

	  <!-- Theme CSS -->
	 <link href="css/bootstrap-rtl.css" rel="stylesheet"> 
	 <link href="style.css" rel="stylesheet"> 
</head>
<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="image/logo.png" width="60%"></a>
       <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" id="menu" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        القائمة
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="admin.php">الرئيسية</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="myaccount.php">حسابي </a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#portfolio">إضافة إعلان</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="logout.php">تسجيل الخروج</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- start header -->
   <!-- Masthead -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container d-flex align-items-center flex-column">

      <!-- Masthead Avatar Image -->
      <img class="masthead-avatar mb-5" src="image/avatar2.png" alt="">

      <!-- Masthead Heading -->
      <h1 class="masthead-heading text-uppercase mb-0">Seren Saad</h1>
    </div>
  </header>
  <!-- end header -->

 <!-- Add event Section Form -->
    <section class="page-section" id="portfolio">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">

          <form name="addevent"  novalidate="novalidate">
            <div class="control-group">
              <div class="form-group  controls mb-0 pb-2">
                <label id="labeL">رفع صورة</label>
                <input class="form-control" id="input_border" type="file">
              </div>
            </div>
            <div class="control-group">
              <div class="form-group  controls mb-0 pb-2">
                <label id="labeL">معلومات إضافة </label>
                <textarea class="form-control" id="input_border" name="info"></textarea>
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <br>
            <div id="success"></div>
            <div class="form-group">
              <input  class="btn btn-primary btn-xl" id="sendMessageButton" type="submit" name="send" value="إضافة">
            </div>
          </form>
        </div>
      </div>

    </div>
  </section>
<!-- end events Section  -->

<!-- start footer Section  -->
  <footer class="footer text-center">
    <div class="container">
      <div class="row">

        <!-- Footer Location -->
        <div class=" col-lg-4 mb-5 mb-lg-0">
        </div>
        <div class=" col-lg-4 mb-5 mb-lg-0">
          <h4 class=" mb-4">من نحن</h4>
          <p class=" lead mb-0">كثيرًا ما يواجهنا نحن كطلاب صعوبة في إحصاء الفعاليات والدورات التي تقيمها الجامعةوفي معظم الأحيان يكون النسيان هو المعضلة الأكبر.

<br> 

فمن هذا المنطلق ظهرت فكرة إنشاء موقع خاص بعرض الإعلانات والفعاليات واللقاءات مع خاصية التذكير.   </p>
        </div>
        <div class=" col-lg-4 mb-5 mb-lg-0">
        </div>

      </div>
    </div>
  </footer>
<!-- end footer Section  -->

  <!-- Copyright Section -->
  <section class="copyright py-4 text-center text-white">
    <div class="container">
      <small>جميع الحقوق محفوظة  &copy; UNIEvents</small>
    </div>
  </section>

<!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Contact Form JavaScript -->
  <script src="js/jqBootstrapValidation.js"></script>
  <script src="js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/freelancer.min.js"></script>
</body>
</html>